import"./BRMBOcdX.js";const i=""+new URL("loading_spinner.ZXMwgfST.gif",import.meta.url).href;export{i as _};
