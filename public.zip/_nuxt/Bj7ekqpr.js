import"./BRMBOcdX.js";const t=""+new URL("default_profile.BDXlxL15.png",import.meta.url).href;export{t as _};
