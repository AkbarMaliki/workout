import"./BRMBOcdX.js";const t=""+new URL("truck.BDEnnc9J.png",import.meta.url).href;export{t as _};
