import"./CiTU5grJ.js";const t=""+new URL("info_alert.DqzmPv8Y.png",import.meta.url).href;export{t as _};
