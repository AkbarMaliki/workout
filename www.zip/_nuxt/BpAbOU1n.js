import"./CiTU5grJ.js";const t=""+new URL("qr.VE_fftl_.png",import.meta.url).href;export{t as _};
