import"./CiTU5grJ.js";const t=""+new URL("hasnur-agri.D2X5xTCh.png",import.meta.url).href;export{t as _};
