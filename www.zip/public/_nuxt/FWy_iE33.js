import{d as e}from"./B6NmAPGr.js";import"./CMKNNMrE.js";const o={__name:"secret",setup(r){return useCurrentUser().value||e("/login"),(t,s)=>" secret "}};export{o as default};
