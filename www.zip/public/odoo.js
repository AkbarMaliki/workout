function importScripts(scripts) {
    return new Promise((resolve, reject) => {
        var script = document.createElement('script');
        script.src = scripts;
        script.onload = resolve;
        script.onerror = reject;
        document.body.appendChild(script);
    });
}
class Odoo {
    // base_url = "https://dev-ebkm.hasnurgroup.com"
    // base_url="http://localhost:8069"
    base_url = "https://ebkm.hasnuragri.com"
    database = ""
    session_id = "12123123"
    user = { token: false }
    model = '';
    id = false;
    param = {}
    args = []
    field = []
    limit = false
    offset = false
    offline = false
    scrambles = false
    call_kw = "/api/call_kw"
    select = ""
    condition = ""
    order = 'id asc'
    methods = ""
    constructor(option = { base_url: false, offline: false, auth: true, scramble: false }) {
        this.init()
        this.base_url = !option.base_url ? this.base_url : option.base_url
        this.auth = option.auth ?? true
        this.offline = option.offline ?? false
        this.scrambles = option.scramble ?? false
        if (this.auth) {
            this.call_kw = "/api/call_kw"
        } else {
            this.call_kw = "/api/call_kw2"
        }
    }
    async init() {
        if (!window.localforage) {
            await importScripts('https://cdnjs.cloudflare.com/ajax/libs/localforage/1.10.0/localforage.min.js');
        }
        localforage.config({
            driver: [localforage.INDEXEDDB, localforage.WEBSQL, localforage.LOCALSTORAGE],
            name: 'local_db',
            version: 1.0,
            size: 4980736,
            storeName: 'keyvaluepairs',
            description: 'some description'
        });
        this.user = await localforage.getItem('user') ?? { token: false };
    }
    env(model = '') {
        this.model = model;
        return this;
    }
    browse(id) {
        this.id = id
        return this
    }
    async search(args = [], option = { field: ['id', 'name'], limit: false, offset: false, order: 'id asc' }) {
        this.args = args
        if (Array.isArray(option)) {
            this.field = option
        } else {
            this.field = option.field
        }
        let data = {
            model: this.scramble(this.model),
            method: this.scramble('search_read'),
            args: [this.args],
            kwargs: {
                fields: this.field,
            },
            session_id: this.session_id,
        }
        if (option.limit) {
            this.limit = option.limit
            data.kwargs.limit = this.limit
        }
        if (option.offset) {
            this.offset = option.offset
            data.kwargs.offset = this.offset
        }
        if (option.order) {
            this.order = option.order
            data.kwargs.order = this.order
        }
        if (option.field) {
            this.field = option.field
            data.kwargs.fields = option.field
        }
        try {
            let user = await localforage.getItem('user') ?? { token: false };
            const response = await fetch(`${this.base_url}${this.call_kw}/${this.generateRandomString(15)}?session_id=${this.generateRandomString(30)}&scramble=${this.scrambles}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `bearer ${user.token}`
                },
                body: JSON.stringify(data)
            })
            const responseData = await response.json();
            console.log('responseData', responseData)
            if (responseData.status == 'error') {
                if (this.offline) {
                    let offlineSource = await localforage.getItem(this.model)
                    this.alert("Source Offline !", 'bg-blue-400')
                    return offlineSource
                }
                if (responseData.code == 401) {
                    await localforage.removeItem('user')
                    this.user = { token: false }
                    this.alert("Session Expired !", 'bg-red-600')
                    return false
                } else {
                    this.alert(responseData.message, 'bg-red-600')
                }
                return responseData.message
            } else if (responseData.error) {
                this.alert("Error " + responseData.error, 'bg-red-600')
                return responseData.error
            } else {
                if (this.offline) {
                    await localforage.setItem(this.model, JSON.parse(responseData.result))
                }
                return JSON.parse(responseData.result)
            }
        } catch (err) {
            console.log(err)
            if (this.offline) {
                let offlineSource = await localforage.getItem(this.model)
                this.alert("Source Offline !", 'bg-blue-400')
                return offlineSource
            } else {
                this.alert(err, 'bg-red-600')
            }
        }
    }
    async write(param = {}) {
        this.param = param
        try {
            let user = await localforage.getItem('user') ?? { token: false };
            const response = await fetch(`${this.base_url}${this.call_kw}/${this.generateRandomString(15)}?session_id=${this.generateRandomString(30)}&scramble=${this.scrambles}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `bearer ${user.token}`
                },
                body: JSON.stringify({
                    model: this.scramble(this.model),
                    method: this.scramble('write'),
                    args: [
                        this.id,
                        this.param
                    ],
                    kwargs: {},
                    session_id: this.session_id,
                })
            });
            const responseData = await response.json();
            if (responseData.status == 'error') {
                if (this.offline) {
                    let data = await localforage.getItem('write_' + this.model) ?? []
                    data.push({ id: this.id, param: this.param, sync: false })
                    await localforage.setItem('write_' + this.model, data)
                    this.alert("Update Data Saved Offline, Sync Later !", 'bg-blue-400')
                    return this
                }
                this.alert(responseData.message, 'bg-red-600')
                return responseData.message
            } else {
                if (responseData.result) {
                    let result = JSON.parse(responseData.result)
                    if (result.status == 'error') {
                        this.alert(result.message, 'bg-red-600')
                        return result.message
                    }
                    this.alert("Proses Update Berlangsung !", 'bg-blue-400')
                    return JSON.parse(responseData.result)
                } else {
                    if (responseData.error) {
                        this.alert(responseData.error, 'bg-red-600')
                    } else {
                        this.alert("Proses Update gagal !", 'bg-red-400')
                    }
                    return false
                }
            }
        } catch (err) {
            if (this.offline) {
                let data = await localforage.getItem('write_' + this.model) ?? []
                data.push({ id: this.id, param: this.param, sync: false })
                await localforage.setItem('write_' + this.model, data)
                this.alert("Update Data Saved Offline, Sync Later !", 'bg-blue-400')
            } else {
                this.alert(JSON.stringify(err), 'bg-blue-400')
            }
            return false
        }
    }

    async create(param = {}) {
        this.param = param
        try {
            let user = await localforage.getItem('user') ?? { token: false };
            const response = await fetch(`${this.base_url}${this.call_kw}/${this.generateRandomString(15)}?session_id=${this.generateRandomString(30)}&scramble=${this.scrambles}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `bearer ${user.token}`

                },
                body: JSON.stringify({
                    model: this.scramble(this.model),
                    method: this.scramble('create'),
                    args: [
                        this.param
                    ],
                    kwargs: {},
                    session_id: this.session_id,
                })
            });
            const responseData = await response.json();
            if (responseData.status == 'error') {
                if (this.offline) {
                    let data = await localforage.getItem('create_' + this.model) ?? []
                    data.push({ param: this.param, sync: false })
                    await localforage.setItem('create_' + this.model, data)
                    this.alert("New Data Saved Offline, Sync Later !", 'bg-blue-400')
                    return this
                }
                this.alert(responseData.message, 'bg-red-600')
                return responseData.message
            } else {
                if (responseData.result) {
                    let result = JSON.parse(responseData.result)
                    if (result.status == 'error') {
                        this.alert(result.message, 'bg-red-600')
                        return result.message
                    }
                    this.alert("Proses Create Berlangsung !", 'bg-blue-400')
                    return JSON.parse(responseData.result)
                } else {
                    if (responseData.error) {
                        this.alert(responseData.error, 'bg-red-600')
                    } else {
                        this.alert("Proses Create gagal !", 'bg-red-400')
                    }
                    return false
                }
            }

        } catch (err) {
            if (this.offline) {
                let data = await localforage.getItem('create_' + this.model) ?? []
                data.push({ param: this.param, sync: false })
                await localforage.setItem('create_' + this.model, data)
                this.alert("New Data Saved Offline, Sync Later !", 'bg-blue-400')
            } else {
                this.alert(JSON.stringify(err), 'bg-blue-400')
            }
            return false
        }
    }
    async sync() {
        let data_write = await localforage.getItem('write_' + this.model)
        if (data_write.length > 0) {
            data_write.forEach((e, i) => {
                this.browse(e.id).write(e.param)
                e.sync = true
            })
            await localforage.setItem('write_' + this.model, data_write.filter(e => e.sync == false))
        }
        let data_create = await localforage.getItem('create_' + this.model)
        if (data_create.length > 0) {
            data_create.forEach((e, i) => {
                this.browse(e.id).write(e.param)
                e.sync = true
            })
            await localforage.setItem('create_' + this.model, data_create.filter(e => e.sync == false))
        }
        this.alert("Proses Sync Berlangsung !", 'bg-blue-400')
        return this
    }
    getUser() {
        return this.user.user_detail
    }
    async unlink() {
        try {
            let user = await localforage.getItem('user') ?? { token: false };
            const response = await fetch(`${this.base_url}${this.call_kw}/${this.generateRandomString(15)}?session_id=${this.generateRandomString(30)}&scramble=${this.scrambles}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `bearer ${user.token}`
                },
                body: JSON.stringify({
                    model: this.scramble(this.model),
                    method: this.scramble('unlink'),
                    args: [[this.id]],
                    kwargs: {},
                    session_id: this.session_id,
                })
            });
            const responseData = await response.json();
            if (responseData.result) {
                let result = JSON.parse(responseData.result)
                console.log('result', result)
                if (result.status == 'error') {
                    this.alert(result.message, 'bg-red-400')
                    return false
                }
                this.alert("Proses Berhasil !", 'bg-blue-400')
                return result
            } else {
                this.alert("Proses Delete gagal", 'bg-red-400')
                return false
            }
        } catch (err) {
            this.alert(JSON.stringify(err), 'bg-blue-400')
            return false
        }
    }
    async query(select = "", condition = "") {
        this.select = select
        this.condition = condition
        try {
            let user = await localforage.getItem('user') ?? { token: false };
            const response = await fetch(`${this.base_url}${this.call_kw}/${this.generateRandomString(15)}?session_id=${this.generateRandomString(30)}&scramble=${this.scrambles}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `bearer ${user.token}`
                },
                body: JSON.stringify({
                    model: this.scramble(this.model),
                    method: this.scramble('query'),
                    args: [[this.select], [this.condition]],
                    kwargs: {},
                    session_id: this.session_id,
                })
            });
            const responseData = await response.json();
            if (responseData.result) {
                let result = JSON.parse(responseData.result)
                if (result.status == 'error') {
                    this.alert(result.message, 'bg-red-400')
                    return false
                }
                this.alert("Proses Berhasil !", 'bg-blue-400')
                return result
            } else {
                this.alert("Proses query gagal", 'bg-red-400')
                return false
            }
        } catch (err) {
            this.alert(JSON.stringify(err), 'bg-blue-400')
            return false
        }
        return this
    }
    async sql(select = false) {
        if (!select) {
            return false
        }
        select = this.scramble(select)
        try {
            let user = await localforage.getItem('user') ?? { token: false };
            const response = await fetch(`${this.base_url}${this.call_kw}/${this.generateRandomString(15)}?session_id=${this.generateRandomString(30)}&scramble=${this.scrambles}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `bearer ${user.token}`
                },
                body: JSON.stringify({
                    model: this.scramble(this.model),
                    method: this.scramble('sql'),
                    args: [[select]],
                    kwargs: {},
                    session_id: this.session_id,
                })
            });
            const responseData = await response.json();
            if (responseData.result) {
                let result = JSON.parse(responseData.result)
                if (result.status == 'error') {
                    console.log('result', result)
                    this.alert(result.message, 'bg-red-400')
                    return false
                }
                this.alert("Proses Berhasil !", 'bg-blue-400')
                return result
            } else {
                this.alert("Proses query gagal", 'bg-red-400')
                return false
            }
        } catch (err) {
            this.alert(JSON.stringify(err), 'bg-blue-400')
            return false
        }
        return this
    }
    async method(method = "") {
        this.methods = method
        try {
            let user = await localforage.getItem('user') ?? { token: false };
            const response = await fetch(`${this.base_url}${this.call_kw}/${this.generateRandomString(15)}?session_id=${this.generateRandomString(30)}&scramble=${this.scrambles}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `bearer ${user.token}`
                },
                body: JSON.stringify({
                    model: this.scramble(this.model),
                    method: this.scramble(this.methods),
                    args: [[this.id]],
                    kwargs: {},
                    session_id: this.session_id,
                })
            });
            const responseData = await response.json();
            if (responseData.result) {
                let result = JSON.parse(responseData.result)
                if (result.status == 'error') {
                    this.alert(result.message, 'bg-red-400')
                    return false
                }
                this.alert("Proses Berhasil !", 'bg-blue-400')
                return result
            } else {
                // this.alert("Proses method gagal", 'bg-red-400')
                return false
            }
        } catch (err) {
            this.alert(JSON.stringify(err), 'bg-blue-400')
            return false
        }
    }
    importScript(link) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = link;
            script.onload = () => resolve();
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }
    base64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                const base64String = btoa(reader.result);
                resolve(base64String);
            };
            reader.onerror = reject;
            reader.readAsBinaryString(file);
        });
    }
    // async login(username, password) {
    //     try {
    //         console.log('this.base_url', this.base_url)
    //         const response = await fetch(this.base_url + `/api/login/mobile?username=${this.scramble(username)}&password=${this.scramble(password)}&scramble=${this.scrambles}`);
    //         const responseData = await response.json();
    //         if (responseData.status == 'error') {
    //             this.alert("Login Gagal", 'bg-red-400')
    //             return false
    //         } else {
    //             this.alert("Login Berhasil", 'bg-blue-400')
    //             await localforage.setItem('user', responseData)
    //             this.user = responseData
    //             return responseData
    //         }
    //     } catch (err) {
    //         console.log('error login : ',err)
    //         this.alert("Login ke sistem tidak berhasil !", 'bg-red-400')
    //     }
    // }
    async login(username, password) {
        try {
            console.log('this.base_url', this.base_url)

            const formData = new FormData();
            formData.append('username', this.scramble(username));
            formData.append('password', this.scramble(password));
            formData.append('scramble', this.scrambles);

            const response = await fetch(this.base_url + `/api/login/mobile`, {
                method: 'POST',
                body: formData
            });

            const responseData = await response.json();

            if (responseData.status === 'error') {
                this.alert("Login Gagal", 'bg-red-400');
                return false;
            } else {
                this.alert("Login Berhasil", 'bg-blue-400');
                await localforage.setItem('user', responseData);
                this.user = responseData;
                return responseData;
            }

        } catch (err) {
            console.log('error login : ', err);
            this.alert("Login ke sistem tidak berhasil !", 'bg-red-400');
        }
    }
    generateRandomString(length) {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let hash = '';
        for (let i = 0; i < length; i++) {
            const randomIndex = Math.floor(Math.random() * characters.length);
            hash += characters[randomIndex];
        }
        return hash;
    }
    async logout() {
        await localforage.removeItem('user')
        this.user = { token: false }
        this.alert("Logout Berlangsung !", 'bg-blue-400')
    }
    async is_login() {
        return await localforage.getItem('user')
    }
    // =========================================== FUNCTIONAL
    alert(text, color = 'bg-red-600') {
        popupMsg(text, color);
    }
    async confirm(text, choice = ['Yes', 'No'], color = 'bg-red-600') {
        await new Promise((resolve, reject) => {
            confirmAdd(text, resolve, choice);
        });
        confirmRemove();
        return jawabanconfirm;
    }
    loadingOn() {
        loadingScreenAdd();
    }
    loadingOff() {
        loadingScreenRemove();
    }
    scramble(datas) {
        let data = datas
        if (this.scrambles) {
            data = scramble(datas);
        }
        return data
    }
}


async function verifyEnc() {
    var encrypted = 'kinonotabi';
    return encrypted
}

function popupMsg(txt, color) {
    let div = document.createElement('div')
    div.setAttribute('id', 'popup-msg')
    div.setAttribute('style', 'position:fixed;top:30px;right:30px;z-index:10000;')
    div.setAttribute('class', `rounded-lg shadow ${color} text-white animated fadeInDown p-3`);
    div.addEventListener('click', (e) => {
        console.log(e.target.remove())
    })
    div.innerHTML = txt;
    document.querySelector('body').appendChild(div);
    setTimeout(() => {
        document.querySelector('#popup-msg').classList.remove('fadeInDown');
        document.querySelector('#popup-msg').classList.add('fadeOutUp');
        setTimeout(() => {
            document.querySelector('#popup-msg').remove();
        }, 1000);
    }, 2000);
}

function loadingScreenAdd(txt, color) {
    let div = document.createElement('div')
    let div2 = document.createElement('div')
    div.addEventListener('click', function () {
        setTimeout(() => {
            loadingScreenRemove();
            popupMsg('Refresh apabila loading terlalu lama dan data tidak terupdate!', 'bg-red-400');
        }, 500);
    })
    div.setAttribute('id', 'loadingScreen')
    div.setAttribute('style', 'position:fixed;top:0;left:0;z-index:10000;height:100vh;width:100vw;background:rgb(0,0,0,0.5)')
    div.setAttribute('class', ` animated fadeIn d-flex justify-content-center align-items-center`);
    div2.setAttribute('id', 'loadingScreen2')
    div2.setAttribute('class', `text-xl text-white font-bold text-center italic lds-ripple`);
    div2.innerHTML = '<div class=""></div><br><br><br><p class="text-center"> Loading </p>';
    div.appendChild(div2);
    document.querySelector('body').appendChild(div);

}

function loadingScreenRemove() {
    document.querySelector('#loadingScreen').classList.remove('fadeIn');
    document.querySelector('#loadingScreen').classList.add('fadeOut');
    setTimeout(() => {
        document.querySelector('#loadingScreen').remove();
    }, 500);
}

function jikayes() {
    alert('woke')
}

function jikano() {
    alert('no')
}

async function confirmAdd(txt, resolve, choice = ['Yes', 'No']) {
    let div = document.createElement('div')
    let div2 = document.createElement('div')
    let divrow1 = document.createElement('div')
    let divrow2 = document.createElement('div')
    let divcol6p1 = document.createElement('div')
    let divcol4p1 = document.createElement('div')
    let divcol4p2 = document.createElement('div')
    let divcol4p3 = document.createElement('div')
    let buttonx = document.createElement('button')
    let buttonyes = document.createElement('button')
    let buttonno = document.createElement('button')
    let ptext = document.createElement('p')
    let garis = document.createElement('hr')
    div.setAttribute('id', 'confirmScreen')
    div.setAttribute('style', 'position:fixed;top:0;left:0;z-index:10000;height:100vh;width:100vw;background:rgb(0,0,0,0.5)')
    div.setAttribute('class', ` animated fadeIn d-flex justify-content-center align-items-center`);
    div2.setAttribute('id', 'confirmScreen2')
    div2.setAttribute('class', ``);
    divrow1.setAttribute('class', 'row justify-content-center')
    divrow1.setAttribute('style', 'width:100vw;')
    divrow2.setAttribute('class', 'row justify-content-between')
    divcol6p1.setAttribute('class', 'animate__animated animate__backInDown bg-white rounded-lg p-3 shadow col-10 col-sm-6')
    divcol6p1.setAttribute('style', 'min-height:35h;')
    divcol4p1.setAttribute('class', 'offset-2 col-4')
    divcol4p2.setAttribute('class', 'col-4')
    divcol4p3.setAttribute('class', 'col-2')
    buttonx.setAttribute('class', 'btn btn-sm btn-dark  float-right')
    buttonx.innerHTML = 'x'
    buttonyes.setAttribute('class', 'btn btn-sm btn-success  btn-block')
    buttonyes.innerHTML = '<span class="typcn typcn-tick"></span> ' + choice[0]
    buttonno.setAttribute('class', 'btn btn-sm btn-danger  btn-block')
    buttonno.innerHTML = '<span class="typcn typcn-cancel"></span> ' + choice[1]
    ptext.setAttribute('class', 'font-semibold text-xl')
    ptext.innerHTML = `${txt}`;
    divcol4p2.appendChild(buttonno);
    divcol4p1.appendChild(buttonyes);
    divrow2.appendChild(divcol4p1);
    divrow2.appendChild(divcol4p2);
    divrow2.appendChild(divcol4p3);
    divcol6p1.appendChild(buttonx);
    divcol6p1.appendChild(ptext);
    divcol6p1.appendChild(garis);
    divcol6p1.appendChild(divrow2);
    divrow1.appendChild(divcol6p1);
    div2.appendChild(divrow1)
    div.appendChild(div2);
    buttonx.addEventListener('click', function () {
        jawabanconfirm = false;
        resolve('no');
    })
    buttonyes.addEventListener('click', function () {
        jawabanconfirm = true;
        resolve('yes');
    })
    buttonno.addEventListener('click', function () {
        jawabanconfirm = false;
        resolve('no');
    })
    document.querySelector('body').appendChild(div);
}

function confirmRemove() {
    document.querySelector('#confirmScreen').classList.remove('fadeIn');
    document.querySelector('#confirmScreen').classList.add('fadeOut');
    setTimeout(() => {
        document.querySelector('#confirmScreen').remove();
    }, 1000);
}

function scramble(teks) {
    let char = "";
    let hasil = "";
    for (var i = 0; i < teks.length; i++) {
        char = "";
        char = teks.charAt(i);
        if (char == "a") {
            char = char.replace("a", "x");
        } else if (char == "b") {
            char = char.replace("b", "v");
        } else if (char == "c") {
            char = char.replace("c", "u");
        } else if (char == "d") {
            char = char.replace("d", "w");
        } else if (char == "e") {
            char = char.replace("e", "y");
        } else if (char == "f") {
            char = char.replace("f", "z");
        } else if (char == "g") {
            char = char.replace("g", "t");
        } else if (char == "h") {
            char = char.replace("h", "s");
        } else if (char == "i") {
            char = char.replace("i", "r");
        } else if (char == "j") {
            char = char.replace("j", "q");
        } else if (char == "k") {
            char = char.replace("k", "p");
        } else if (char == "l") {
            char = char.replace("l", "o");
        } else if (char == "m") {
            char = char.replace("m", "n");
        } else if (char == "z") {
            char = char.replace("z", "f");
        } else if (char == "y") {
            char = char.replace("y", "e");
        } else if (char == "x") {
            char = char.replace("x", "a");
        } else if (char == "w") {
            char = char.replace("w", "d");
        } else if (char == "v") {
            char = char.replace("v", "b");
        } else if (char == "u") {
            char = char.replace("u", "c");
        } else if (char == "t") {
            char = char.replace("t", "g");
        } else if (char == "s") {
            char = char.replace("s", "h");
        } else if (char == "r") {
            char = char.replace("r", "i");
        } else if (char == "q") {
            char = char.replace("q", "j");
        } else if (char == "p") {
            char = char.replace("p", "k");
        } else if (char == "o") {
            char = char.replace("o", "l");
        } else if (char == "n") {
            char = char.replace("n", "m");
        } else if (char == "1") {
            char = char.replace("1", "0");
        } else if (char == "2") {
            char = char.replace("2", "8");
        } else if (char == "3") {
            char = char.replace("3", "9");
        } else if (char == "4") {
            char = char.replace("4", "7");
        } else if (char == "5") {
            char = char.replace("5", "6");
        } else if (char == "0") {
            char = char.replace("0", "1");
        } else if (char == "8") {
            char = char.replace("8", "2");
        } else if (char == "9") {
            char = char.replace("9", "3");
        } else if (char == "7") {
            char = char.replace("7", "4");
        } else if (char == "6") {
            char = char.replace("6", "5");
        } else if (char == " ") {
            char = char.replace(" ", "_");
        } else if (char == "_") {
            char = char.replace("_", " ");
        } else if (char == "*") {
            char = char.replace("*", "/");
        } else if (char == "/") {
            char = char.replace("/", "*");
        } else if (char == ",") {
            char = char.replace(",", "^");
        } else if (char == "^") {
            char = char.replace("^", ",");
        }
        hasil = hasil + char;
    }
    return hasil;
}

let style = document.createElement('style')
style.innerHTML = `
.lds-ripple {
  display: inline-block;
  position: relative;
  width: 80px;
  height: 80px;
}
.lds-ripple div {
  position: absolute;
  border: 4px solid #fff;
  opacity: 1;
  border-radius: 50%;
  animation: lds-ripple 1s cubic-bezier(0, 0.2, 0.8, 1) infinite;
}
.lds-ripple div:nth-child(2) {
  animation-delay: -0.5s;
}
@keyframes lds-ripple {
  0% {
    top: 36px;
    left: 36px;
    width: 0;
    height: 0;
    opacity: 1;
  }
  100% {
    top: 0px;
    left: 0px;
    width: 72px;
    height: 72px;
    opacity: 0;
  }
}
`;
document.head.appendChild(style);
